from django.http import HttpResponse
from django.shortcuts import  render

def index(request):
    return render(request, 'index.html')





def analyze(request):
    djtext = request.POST.get('text', 'default')

    removepunc = request.POST.get('removepunc', 'off')

    fullcaps = request.POST.get('fullcaps', 'off')

    lowercaps = request.POST.get('lowercaps', 'off')
    newlineremover = request.POST.get('newlineremover', 'off')
    extraspaceremover = request.POST.get('extraspaceremover', 'off')
    charcount = request.POST.get('charcount', 'off')


    print(removepunc)
    print(djtext)
    if removepunc == "on":
        punctuation = '''"#$%&'()*+,-./:;<=>?@[\]^_`{|}~'''
        analyzed = ""
        for char in djtext :
            if char not in punctuation:
                analyzed = analyzed+char
        params = {'purpose': 'removepunctuation' , 'analyzed_text':analyzed}
        return render(request , 'analyze.html', params)


    elif (fullcaps =="on"):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed+char.upper()

        params = {'purpose': 'change to upper case' , 'analyzed_text':analyzed}
        return render(request , 'analyze.html', params)


    elif (lowercaps =="on"):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed+char.lower()

        params = {'purpose': 'change to lower case' , 'analyzed_text':analyzed}
        return render(request , 'analyze.html', params)

    elif (newlineremover =="on"):
        analyzed = ""
        for char in djtext:
            if char !="\n" and char!="\r":
                analyzed = analyzed+char
        params = {'purpose': ' remove to new line' , 'analyzed_text':analyzed}
        return render(request , 'analyze.html', params)

    elif(extraspaceremover=="on"):
        analyzed = ""
        for index, char in enumerate(djtext):
            if not(djtext[index] == " " and djtext[index+1]==" "):
                analyzed = analyzed + char

        params = {'purpose': 'Removed NewLines', 'analyzed_text': analyzed}

        # Analyze the text
        return render(request, 'analyze.html', params)

    elif(charcount=="on"):
        analyzed = ""
        analyzed = len(djtext)
        params = {'purpose': 'count the character in your given texts', 'analyzed_text': analyzed}
        return render(request, 'analyze.html', params)

    else:
        return HttpResponse("Error")













































# def capfirst(request):
#         return HttpResponse("<h1> this is capfirst page jisse hum bolte h capfirst page </h1>  ")
# def newlineremove(request):
#         return HttpResponse("<h1> this is newlineremove  page jisse hum bolte h newlineremove page </h1>  ")
# def spaceremove(request):
#        return HttpResponse("<h1> this is spaceremove page jisse hum bolte h spaceremove page </h1>  ")
# def charcount(request):
#         return HttpResponse("<h1> this is charcount page jisse hum bolte h charcount spage </h1>  ")
#
